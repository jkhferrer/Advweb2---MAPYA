<!-- footer -->
	<div class="footer">
		<div class="container">
			<p>© 2016 All rights reserved | Design by Team Mapya</a></p>
			<div class="social">
				<ul>
					<li><a href="#"><i class="fb"></i></a></li>
					<li><a href="#"><i class="twt"></i></a></li>
					<li><a href="#"><i class="goop"></i></a></li>
					<li><a href="#"><i class="pp"></i></a></li>
						<div class="clearfix"> </div>
				</ul>
			</div>
			<h3>Telephone : 2587-568-4587</h3>
		</div>
	</div>
<!-- footer -->
</body>
</html>