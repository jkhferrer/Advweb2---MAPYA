
<!-- header -->
<div class="banner">
	<div class="callbacks_container">
	      <ul class="rslides" id="slider">
	        <li>
	          <img src="assests/images/palawan.jpg" class="img-responsive" alt="">
	        </li>
	        <li>
	          <img src="assests/images/choco.jpg" class="img-responsive" alt="">
	        </li>
	        <li>
	          <img src="assests/images/banner3.jpg" class="img-responsive" alt="">
	        </li>
	      </ul>
	  </div>
	  <div class="header">
				<div class="logo">
					<a href="welcome/view"><img src="assests/images/lite.png" class="img-responsive" alt="" /></a>
				</div>
				<div class="head-nav">
						<span class="menu"> </span>
							<ul class="cl-effect-16">
								<li class="active"><a href="welcome/view" data-hover="HOME">HOME</a></li>
								<li><a href="/about" data-hover="ABOUT">ABOUT</a></li>
								<li><a href="/404" data-hover="RENTALS">RENTALS</a></li>
								<li><a href="/destination" data-hover="DESTINATIONS">DESTINATIONS</a></li>
								<li><a href="/contact" data-hover="CONTACTS">CONTACTS</a></li>
									<div class="clearfix"> </div>
							</ul>
				</div>
						<div class="clearfix"> </div>
					<!-- script-for-nav -->
					<script>
						$( "span.menu" ).click(function() {
						  $( ".head-nav ul" ).slideToggle(300, function() {
							// Animation complete.
						  });
						});
					</script>
				<!-- script-for-nav -->
			</div>
  </div>