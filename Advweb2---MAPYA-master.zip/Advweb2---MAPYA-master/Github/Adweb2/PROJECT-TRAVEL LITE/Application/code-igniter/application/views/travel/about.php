
<!-- header -->
<div class="banner-1">
<div class="container">
	  <div class="header-1">
				<div class="logo1">
					<a href="index.html"><img src="<?php echo base_url(); ?>assests/images/logo.png" class="img-responsive" alt="" /></a>
				</div>
				<div class="head-nav">
						<span class="menu"> </span>
							<ul class="cl-effect-16">
								<li><a href="index.php" data-hover="HOME">HOME</a></li>
								<li class="active"><a href="about.php" data-hover="ABOUT">ABOUT</a></li>
								<li><a href="404.php" data-hover="RENTALS">RENTALS</a></li>
								<li><a href="destination.php" data-hover="DESTINATIONS">DESTINATIONS</a></li>
								<li><a href="contact.php" data-hover="CONTACTS">CONTACTS</a></li>
									<div class="clearfix"> </div>
							</ul>
				</div>
						<div class="clearfix"> </div>
					<!-- script-for-nav -->
					<script>
						$( "span.menu" ).click(function() {
						  $( ".head-nav ul" ).slideToggle(300, function() {
							// Animation complete.
						  });
						});
					</script>
				<!-- script-for-nav -->
			</div>
			</div>
  </div>
<!-- header -->
<!-- about -->	
		<div class="about">
		<div class="container">
				<div class="col-md-4 about-topgrid1">
										<h3>Who We Are</h3>
										<img src="<?php echo base_url(); ?>assests/images/01.jpg"  class="img-responsive" title="name">
										<h4>Team Mapya!</p>
										<p>These individuals are all students from Asia Pacific College who loves spending their idle time going to vacations. They all experience all the hassles and problems in planning a trip for their families or with their barkadas and that’s where gentlemen came up with the idea.</p>
									</div>
					<div class="col-md-4 about-histore">
									<h3>Our History</h3>
									<div class="historey-lines">
										<ul>
											<li><span>2010 &nbsp;-</span></li>
											<li><p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aeonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi.</p></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
									<div class="historey-lines">
										<ul>
											<li><span>2010 &nbsp;-</span></li>
											<li><p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aeonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi.</p></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
									<div class="historey-lines">
										<ul>
											<li><span>2010 &nbsp;-</span></li>
											<li><p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aeonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi.</p></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
									<div class="historey-lines">
										<ul>
											<li><span>2010 &nbsp;-</span></li>
											<li><p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aeonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi.</p></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
									<div class="historey-lines">
										<ul>
											<li><span>2010 &nbsp;-</span></li>
											<li><p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aeonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi.</p></li>
											<div class="clear"> </div>
										</ul>
									</div>
									<div class="clearfix"> </div>
								</div>
					<div class="col-md-4 about-services">
									<h3>our services</h3>
									<h4>LOREM IPM DOLOR SIT AMET, CONSECTETUER ADIPISCING ELIT. PRAESENT VESTIBULUM.</h4>
									<p>Praesent vestibulum molestie lacus. Aeonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi. Morbi nunc odio, gida at, cursus nec, luctus a, lorem. Maecenas tristique orci ac sem. Duis ultricies pharetra magna. Donec accumsan malesuada orci. Donec sit amet eros.</p>
									<ul>
										<li><a href="#">consectetur adipisicing elit</a></li>
										<li><a href="#">sed do eiusmod tempor incididunt</a></li>
										<li><a href="#">labore et dolore magna aliqua.</a></li>
										<li><a href="#">sed do eiusmod tempor</a></li>
										<li><a href="#">abore et dolore magna</a></li>
										<li><a href="#">incididunt ut labore et dolore</a></li>
										<div class="clearfix"> </div>
									</ul>
								</div>
								<div class="clearfix"> </div>
						
			</div>
</div>
<!-- about -->	