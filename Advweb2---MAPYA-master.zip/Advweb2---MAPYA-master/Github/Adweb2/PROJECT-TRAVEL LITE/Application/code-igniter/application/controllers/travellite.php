<?php
class travellite extends CI_Controller{
	
		
}