<!-- header -->
<div class="banner-1">
<div class="container">
	  <div class="header-1">
				<div class="logo1">
					<a href="index.html"><img src="<?php echo base_url(); ?>assests/images/logo.png" class="img-responsive" alt="" /></a>
				</div>
				<div class="head-nav">
						<span class="menu"> </span>
							<ul class="cl-effect-16">
								<li><a href="index.php" data-hover="HOME">HOME</a></li>
								<li><a href="about.php" data-hover="ABOUT">ABOUT</a></li>
								<li class="active"><a href="404.php" data-hover="RENTALS">RENTALS</a></li>
								<li><a href="destination.php" data-hover="DESTINATIONS">DESTINATIONS</a></li>
								<li><a href="contact.php" data-hover="CONTACTS">CONTACTS</a></li>
									<div class="clearfix"> </div>
							</ul>
				</div>
						<div class="clearfix"> </div>
					<!-- script-for-nav -->
					<script>
						$( "span.menu" ).click(function() {
						  $( ".head-nav ul" ).slideToggle(300, function() {
							// Animation complete.
						  });
						});
					</script>
				<!-- script-for-nav -->
			</div>
			</div>
  </div>
<!-- header -->
<div class="404">
<div class="container">
			<!--start-plans-404page---->
			<div class="error-page">
				<p>Under Construction! :(</p>
				<h3>404</h3>
				<a href="index.html" class="btn  btn-1c">Go home</a>
			</div>
			<!--End-plans-404page---->
			<div class="clearfix"> </div>
		</div>
	</div>